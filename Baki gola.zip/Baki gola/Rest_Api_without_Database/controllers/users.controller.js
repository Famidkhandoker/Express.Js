const getAllusers=(req,res)=>{
    res.status(200).json({users});
};

module.expors={getAllusers};